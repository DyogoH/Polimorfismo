/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author dyogo
 */


public class AtualizadorDeContas {
    private double saldoTotal = 0;
    private double selic;

    public AtualizadorDeContas(double selic) {
        this.selic = selic;
    }

    public void roda(Conta c) {
        double saldoAnterior = c.getSaldo();
        c.atualiza(this.selic);
        double saldoNovo = c.getSaldo();
        System.out.printf("Saldo anterior: %.2f\n", saldoAnterior);
        System.out.printf("Saldo novo: %.2f\n", saldoNovo);
        saldoTotal += saldoNovo;
    }

    public double getSaldoTotal() {
        return saldoTotal;
    }
}

